# WEBD6201-W2021-ICE2b

This is a demo project for ICE 2
